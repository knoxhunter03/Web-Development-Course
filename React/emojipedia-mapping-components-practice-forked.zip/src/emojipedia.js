const emojipedia = [
  {
    id: 1,
    emoji: "💪",
    name: "Tense Biceps",
    meaning:
      "“You can do that!” or “I feel strong!” Arm with tense biceps. Also used in connection with doing sports, e.g. at the gym."
  },
  {
    id: 2,
    emoji: "🙏",
    name: "Person With Folded Hands",
    meaning:
      "Two hands pressed together. Is currently very introverted, saying a prayer, or hoping for enlightenment. Is also used as a “high five” or to say thank you."
  },
  {
    id: 3,
    emoji: "🤣",
    name: "Rolling On The Floor, Laughing",
    meaning:
      "This is funny! A smiley face, rolling on the floor, laughing. The face is laughing boundlessly. The emoji version of “rofl“. Stands for „rolling on the floor, laughing“."
  },
  {
    id: 4,
    emoji: "💦",
    name: "Splashing Sweat Symbol",
    meaning:
      "The drops represent splashing sweat. Somebody is making either a physical or a mental effort right now. In sexual contact for body fluids or excitement."
  },
  {
    id: 5,
    emoji: "🍑",
    name: "Peach",
    meaning:
      "Soft skin, juicy and sweet pulp, aromatic smell: the peach is considered a seductive fruit. Due to the characteristic shape, the most commonly used emoji for the female butt."
  },
  {
    id: 6,
    emoji: "🍆",
    name: " Eggplant",
    meaning:
      "The eggplant is associated with the male sex. It is one of the sex symbols. Is hated and loved on Instagram #freetheeggplant."
  }
];

export default emojipedia;
